#### CODE FOR TESTING CHANNEL FIRST AND CHANNEL LAST ####

    # c_first = to_channels_first()
    # c_last = to_channels_last()
    # input = torch.rand(1, 4, 32, 32, 32)
    # # Convert to channel last
    # print("channel last: \n")
    # out = c_last(input)
    # print(out.shape)

    # # convert back to channel first
    # print("channel first: \n")
    # out1 = c_first(out)
    # print(out1.shape)



#### CODE FOR TESTING NORM LAYER #####
    # c_last = to_channels_last()
    # input = c_last(input)
    # norm = build_norm_layer(dim=4, norm_layer="LN")
    # out = norm(input)
    # print(out.shape)


#### CODE TO TEST ACTIVATION LAYER ####
    # ACTIVATION LAYER TESTING
    # activation_type = "GELU"
    # act = build_act_layer(activation_type)
    # out = act(input)
    # print(out.shape)


### STEM LAYER ###

    # # CODE TO TEST STEM LAYER
    # stem_layer = StemLayer(in_chans=4, out_chans=32, act_layer="GELU", 
    #                        norm_layer="LN")
    # output = stem_layer(input)
    # print(output.shape)


### CODE TO TEST DOWNSAMPLE LAYER ###
    # CODE TO DOWNSAMPLE layer
    # down_sample = DownsampleLayer(channels=4, norm_layer="LN")
    # out = down_sample(input)
    # print(out.shape)
    